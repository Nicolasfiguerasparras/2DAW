// let primera;
// let puntuacion=9,record="9",jugador;
// let correcta="ok";
// let _correcta2=8;
// let $correctisima=4.78;
// let correcta_de_mas=true;
// //let 1incorrecta="blue";
// puntuacion=0;
// record=5000;
// jugador="Juan";

// alert(primera);
// alert(puntuacion);
// alert(_correcta2);


// alert(4+6-2);


// alert(isNaN("Dani"));

// let numeros=[12,2,-1,90];

// numeros[0]=12;
// numeros[1]=2;
// numeros[2]=-1;
// numeros[3]=90;

// numeros[4]=-6;


// numeros[10]=1230;
// alert(numeros[11]);


// let respuesta=confirm("Esta satisfecho con la aplicacion");
// alert(respuesta);
// let puntuacion=prompt("Puntue la aplicacion del 1 al 10");
// alert("Su puntuacion ha sido de "+ puntuacion+" gracias por su visita");

let numero1,numero2,suma,resta;
numero1=parseFloat(prompt("Introduzca un numero"));
numero2=parseFloat(prompt("Introduzca un numero"));


suma=numero1+numero2;
alert(suma);
// resta=numero1-numero2;
// alert(resta);
