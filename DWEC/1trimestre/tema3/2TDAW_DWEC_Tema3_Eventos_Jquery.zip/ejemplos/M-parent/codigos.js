function Aumentar()
{
    $("#mas").parent().css("font-size","+=2");
}

function Disminuir()
{
    $("#menos").parent().css("font-size","-=2");
}

