let num1 = parseFloat(prompt("Introduce el primer numero"));
let num2 = parseFloat(prompt("Introduce el segundo numero"));
let num3 = parseFloat(prompt("Introduce el tercero numero"));
let num4 = parseFloat(prompt("Introduce el cuarto numero"));

let media = (num1+num2+num3+num4)/4;

alert("La media de los cuatro numeros introducidos es de: "+media) 