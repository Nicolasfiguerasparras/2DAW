let num1=parseFloat(prompt("Introduce el primer numero"));
let num2=parseFloat(prompt("Introduce el segundo numero"));
let num3=parseFloat(prompt("Introduce el tercer numero"));
let opcion;

if (num1==num2 && num1==num3) {
	opcion=true;
	alert(opcion);
}else{
	opcion=false;
	alert(opcion);
}