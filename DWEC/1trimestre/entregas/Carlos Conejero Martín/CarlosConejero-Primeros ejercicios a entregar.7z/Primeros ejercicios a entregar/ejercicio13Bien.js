let dia=parseInt(prompt("Introduce el dia"));
let mes=prompt("Introduce el mes");
let anio=parseInt(prompt("Introduce el año"));


switch(mes) {
	case "enero":
		if(dia>0 && dia<=31) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "febrero":
		if(dia>0 && dia<=28) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "marzo":
		if(dia>0 && dia<=31) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "abril":
		if(dia>0 && dia<=30) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "mayo":
		if(dia>0 && dia<=31) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "junio":
		if(dia>0 && dia<=30) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "julio":
		if(dia>0 && dia<=31) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "agosto":
		if(dia>0 && dia<=31) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "septiembre":
		if(dia>0 && dia<=30) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "octubre":
		if(dia>0 && dia<=31) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "noviembre":
		if(dia>0 && dia<=30) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	case "diciembre":
		if(dia>0 && dia<=31) {
			document.write(dia+" de "+mes+" del "+anio);
		}else{
			document.write("Fecha incorrecta");
		}
		break;
	default:
		document.write("Error. Fecha incorrecta");
}
