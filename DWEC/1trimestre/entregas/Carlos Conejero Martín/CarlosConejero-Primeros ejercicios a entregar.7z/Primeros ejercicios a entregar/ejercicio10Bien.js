let num1=parseFloat(prompt("Introduce el primer numero"));
let num2=parseFloat(prompt("Introduce el segundo numero"));
let num3=parseFloat(prompt("Introduce el tercer numero"));
let opcion;

if (num1<10 && num2<10 && num3<10) {
	opcion=true;
	alert(opcion);
}else{
	opcion=false;
	alert(opcion);
}