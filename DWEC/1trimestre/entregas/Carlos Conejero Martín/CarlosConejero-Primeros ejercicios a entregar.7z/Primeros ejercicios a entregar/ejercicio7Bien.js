let num = parseFloat(prompt("Introduce el numero"));

let cuadrado = num*num;
let cubo = num*num*num;

alert("El cuadrado de "+num+" es de: "+cuadrado);
alert("El cubo de "+num+" es de: "+cubo);