let num=parseFloat(prompt("Introduce el numero"));
let opcion;

if (num%2==0) {
	opcion=true;
	alert(opcion);
}else{
	opcion=false;
	alert(opcion);
}