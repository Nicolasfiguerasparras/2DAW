let dia=parseInt(prompt("Introduce el dia"));
let mes=prompt("Introduce el mes");
let anio=parseInt(prompt("Introduce el año"));

if(dia>=24 && dia<32 && mes=="diciembre") {
	alert("FELIZ NAVIDAD");
}else if(dia>=1 && dia<=6 && mes=="enero"){
	alert("FELIZ NAVIDAD");
}else{
	alert("NO ES NAVIDAD");
}