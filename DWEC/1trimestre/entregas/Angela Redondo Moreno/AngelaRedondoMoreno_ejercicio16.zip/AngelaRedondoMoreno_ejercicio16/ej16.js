
let positivos = 0;
let negativos = 0;
let numeros=[];

for(let i=0;i<10;i++){
	numeros[i]=parseFloat(prompt("Dime numeros"));
	if(numeros[i] >0) {
		positivos = positivos + numeros[i];
	}else{
		negativos=negativos-numeros[i];
	}
}

document.write("<table border>");
document.write("<tr><td bgcolor=green>Array inicial</td><td bgcolor=red>"+numeros+"</td></tr>");
document.write("<tr><td bgcolor=green>Positivos</td><td bgcolor=red>"+positivos+"</td></tr>");
document.write("<tr><td bgcolor=green>Negativos</td><td bgcolor=red>"+negativos+"</td></tr>");

if(positivos>negativos){
	document.write("<tr><td bgcolor=green>Total</td><td bgcolor=red>"+positivos+"-"+negativos+"="+(positivos-negativos)+"</td></tr>");
}else{
	document.write("<tr><td bgcolor=green>Total</td><td bgcolor=red>"+negativos+"-"+positivos+"="+(negativos-positivos)+"</td></tr>");
}

document.write("</table>");
