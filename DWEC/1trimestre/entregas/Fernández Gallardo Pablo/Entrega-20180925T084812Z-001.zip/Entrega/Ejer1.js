let nombre, email;

nombre = prompt("Introduzca su nombre");
email = prompt("Introduzca su email");

document.write("Tu nombre es: " + nombre);
document.write("Tu email es: " + email);