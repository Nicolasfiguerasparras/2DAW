let ancho, alto, superficie;

ancho = parseFloat(prompt("Ancho"));
alto = parseFloat(prompt("Alto"));

superficie = alto * ancho;

alert("El ancho es: " + superficie);
