let lado, perimetro, area;

lado = parseFloat(prompt("Introduzca un lado"));

perimetro = lado*4;
area=lado * lado;

alert("El area es: " + area);
alert("El perimetro es: " + perimetro);