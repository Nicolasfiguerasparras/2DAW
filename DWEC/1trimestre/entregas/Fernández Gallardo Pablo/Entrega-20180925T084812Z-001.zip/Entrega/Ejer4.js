let num1, num2, num3, num4, suma, producto;

num1 = parseFloat(prompt("Introduzca un numero"));
num2 = parseFloat(prompt("Introduzca un numero"));
num3 = parseFloat(prompt("Introduzca un numero"));
num4 = parseFloat(prompt("Introduzca un numero"));

suma = num1 * num2;
producto = num3 * num4;

alert("La suma es: " + suma);
alert("El producto es: " + producto);