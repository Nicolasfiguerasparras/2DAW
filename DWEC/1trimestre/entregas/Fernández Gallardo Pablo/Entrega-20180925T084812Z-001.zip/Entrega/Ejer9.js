let num1, num2, oper1, oper2;

num1 = parseInt(prompt("Introduzca un numero entero"));
num2 = parseInt(prompt("Introduzca otro numero entero"));

oper1 = (num1 + num2) * (num1 - num2);
oper2 = Math.pow(num1,2) - Math.pow(num2,2);

document.write("La operacion 1 es: " + oper1);
document.write("La operacion 2 es: " + oper2);