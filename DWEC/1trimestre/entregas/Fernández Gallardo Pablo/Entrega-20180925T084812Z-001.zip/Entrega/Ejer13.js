let dia, mes, anio, verfal;

let dt = new Date();

dia = dt.getDate(prompt("Introduzca un dia"));
mes = dt.getMonth(prompt("Introduzca un mes"));
anio = dt.getFullYear(prompt("Introduzca un anio"));

if(dia > 0 && dia <=31 && mes > 0 && mes <13 && anio > 0 ){
	verfal=true;
}else{
	verfal=false;
}

document.write(verfal);