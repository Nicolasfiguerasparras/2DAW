let num1, num2, num3, num4, media;

num1 = parseFloat(prompt("Introduzca un número"));
num2 = parseFloat(prompt("Introduzca otro número"));
num3 = parseFloat(prompt("Introduzca otro número"));
num4 = parseFloat(prompt("Introduzca otro número"));

media = ((num1+ num2 + num3 +  num4)/4);

alert("La media de " + num1 + "," + num2 + "," + num3 + "y" + num4 +"es: " + media);
