let dia, mes, anio, verfal;

dia = parseInt(prompt("Introduzca un dia"));
mes = parseInt(prompt("Introduzca un mes"));
anio = parseInt(prompt("Introduzca un anio"));

console.log(mes);
if(dia > 0 && dia <=31 && mes > 0 && mes <13 && anio > 0){
	if(mes == 1){
		if(dia >=1){
			alert("Es Navidad");
		}else{
		alert("No Es Navidad");
		}	
	}else if(mes == 12){
		if(dia > 24){
			alert("Es Navidad");
		}else{
			alert("No Es Navidad");
		}
	}else{
		alert("No Es Navidad");
	}
}else{
	alert("No Es Navidad");
}

document.write(verfal);