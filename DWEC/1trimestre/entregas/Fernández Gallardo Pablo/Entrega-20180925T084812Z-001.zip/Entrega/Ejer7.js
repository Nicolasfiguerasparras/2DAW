let num, potencia_cuadra, potencia_cub;

num = parseInt(prompt("Introduzca un numero"));

potencia_cuadra = Math.pow(num,2);
potencia_cub = Math.pow(num,3);

alert("La potencia al cuadrado del numero es: " + potencia_cuadra);

alert("La potencia al cubo del numero es: " + potencia_cub);

