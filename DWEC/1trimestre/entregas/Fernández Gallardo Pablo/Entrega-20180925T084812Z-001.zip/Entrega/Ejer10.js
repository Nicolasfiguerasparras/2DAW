let num1, num2, num3, verfal;

num1 = parseInt(prompt("Introduzca un numero"));
num2 = parseInt(prompt("Introduzca otro numero"));
num2 = parseInt(prompt("Introduzca un tercer numero"));

if(num1 < 10 && num2 < 10 && num3 < 10){
	verfal=false;
}else{
	verfal=true;
}

alert(verfal);