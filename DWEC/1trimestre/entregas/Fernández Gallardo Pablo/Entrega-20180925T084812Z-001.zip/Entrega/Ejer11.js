let num1, num2, num3, verfal;

num1 = parseInt(prompt("Introduzca un valor de tipo entero"));
num2 = parseInt(prompt("Introduzca otro valor de tipo entero"));
num3 = parseInt(prompt("Introduzca un tercer valor de tipo entero"));

if(num1==num2 && num1==num3 && num2==num3){
	verfal=true;
}else{
	verfal=false;
}

document.write(verfal);