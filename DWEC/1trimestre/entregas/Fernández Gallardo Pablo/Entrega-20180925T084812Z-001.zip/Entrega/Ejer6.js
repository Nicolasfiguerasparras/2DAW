let precio, cantidad, abonar, total;

precio = parseFloat(prompt("Introduzca el precio del artículo"));
cantidad = parseFloat(prompt("Introduzca la cantidad que se lleva el cliente"));


abonar = (precio*cantidad);

alert("El precio que debe abonar el comprador es"+abonar);