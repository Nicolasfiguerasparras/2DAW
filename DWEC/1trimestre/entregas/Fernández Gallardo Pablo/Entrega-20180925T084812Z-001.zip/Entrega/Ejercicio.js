let array=[];
array[0]='Jorge';
array[1]='Pérez';
array[2]=35;
array[3]=1.77;
array[4]=80;
array[5]='Moreno';
array[6]='Soltero';

document.write("<table border='1'>"+
					"<tr>"+
						"<td>"+0+"</td>"+
						"<td>"+1+"</td>"+
						"<td>"+2+"</td>"+
						"<td>"+3+"</td>"+
						"<td>"+4+"</td>"+
						"<td>"+5+"</td>"+
						"<td>"+6+"</td>"+

						"</tr>"+
						"<td>"+array[0]+"</td>"+
						"<td>"+array[1]+"</td>"+
						"<td>"+array[2]+"</td>"+
						"<td>"+array[3]+"</td>"+
						"<td>"+array[4]+"</td>"+
						"<td>"+array[5]+"</td>"+
						"<td>"+array[6]+"</td>"+
						"</table border>")