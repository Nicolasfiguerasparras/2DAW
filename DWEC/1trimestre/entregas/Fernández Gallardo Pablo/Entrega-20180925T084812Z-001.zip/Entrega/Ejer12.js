let num1, par, impar;

num1 = parseInt(prompt("Introduzca un numero entero"));

if(num1 % 2 == 0){
	par = true;
}else{
	par = false;
}

document.write(par);