let letra = ["T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"];

let dni;

let numDni;

numDni=parseInt(prompt("Introduzca su dni(solo numeros)"));

dni = numDni % 23;

alert("Te corresponde la letra: " + letra[dni]);
