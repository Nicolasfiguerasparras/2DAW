let user, email;
user = prompt("Introduce tu usuario");
email = prompt("Introduce tu email");
alert("El usuario es " + user);
alert("El email es " + email);