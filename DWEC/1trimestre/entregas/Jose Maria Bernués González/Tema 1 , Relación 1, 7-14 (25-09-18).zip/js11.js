let a, b, c, same;
a = prompt("Introduce un valor");
b = prompt("Introduce otro valor");
c = prompt("Introduce el ultimo valor");

if(a == b && a == c){
	same = true;
} 
else{
	same = false;
}
alert(same);