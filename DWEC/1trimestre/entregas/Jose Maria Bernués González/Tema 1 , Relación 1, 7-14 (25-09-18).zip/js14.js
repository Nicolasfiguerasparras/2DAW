let dd, mm, yy, xmas;
dd = parseInt(prompt("Introduce el dia"));
mm = parseInt(prompt("Introduce el mes"));
yy = parseInt(prompt("Introduce el año"));

if(mm == 12){
	if(dd == 25){
		xmas = true;
		alert(xmas + ", es Navidad!");
	}
	else{
		xmas == false;
		alert(xmas + "ups! aun no es Navidad :(");
	}
}
else{
	alert("No estás ni en diciembre!!!");
}