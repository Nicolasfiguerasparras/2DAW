let n, n2, n3;
n = parseFloat(prompt("Introduce un número"));
n2 = (n * n);
n3 = (n * n * n);
alert("La potencia 2 de " + n + " es " + n2);
alert("La potencia 3 de " + n + " es " + n3);