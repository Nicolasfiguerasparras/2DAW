let dd, mm, yy, date;
dd = parseInt(prompt("Introduce el dia"));
mm = parseInt(prompt("Introduce el mes"));
yy = parseInt(prompt("Introduce el año"));

if(mm == 4 || mm == 6 || mm == 9 || mm == 11){
	if(dd >= 1 && dd <= 30){
		date = true;
		alert(date + ",fecha validada");
	}
	else{
		date = false;
		alert(date + ",este mes tiene entre 1-30 dias");
	}
}
else if(mm == 1 || mm == 3 || mm == 5 || mm == 7 || mm == 8 || mm == 10 || mm == 12){
	if(dd >= 1 && dd <= 31){
		date = true;
		alert(date + ",fecha validada");
	}
	else{
		date = false;
		alert(date + ",este mes tiene entre 1-31 dias");
	}
}
else{
	if(dd >= 1 && dd <= 28){
		date = true;
		alert(date + ",fecha validada");
	}
	else{
		date = false;
		alert(date + ".este mes tiene entre 1-28 dias");
	}
}