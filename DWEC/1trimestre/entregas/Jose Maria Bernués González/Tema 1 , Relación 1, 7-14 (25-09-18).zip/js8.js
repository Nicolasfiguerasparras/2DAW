let C, F, K;
C = parseFloat(prompt("Introduce el numero de grados"));
F = ((C *18)/10 + 32);
K = (C + 273.15);
alert(C + "ºC son " + F + "ºF");
alert(C + "ºC son " + K + "ºK");