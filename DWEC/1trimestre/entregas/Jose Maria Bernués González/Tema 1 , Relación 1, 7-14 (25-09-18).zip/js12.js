let n, even;
n = parseInt(prompt("Introduce el numero"));

if(n % 2 == 0){
	even = true;
	alert(even + " el numero es par");
}
else{
	even = false;
	alert(even + " el numero no es par");
}
