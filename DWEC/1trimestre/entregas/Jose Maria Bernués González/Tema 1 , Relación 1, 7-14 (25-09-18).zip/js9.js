let a, b, rop1, rop2;
a = parseFloat(prompt("Introduce un numero"));
b = parseFloat(prompt("Introduce el otro"));
rop1 = ((a+b) * (a-b));
rop2 = ((a*a)-(b*b))
alert("Resultado 1: " + rop1 + " Resultado 2: " + rop2);

