let hei, wid, area;
hei = parseInt(prompt("Introduzca la altura"));
wid = parseInt(prompt("Introduzca la anchura"));
area = (hei*wid);
alert("El area es " + area);