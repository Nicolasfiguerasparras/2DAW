let n1, n2, n3, menores;
n1 = parseFloat(prompt("Introduce el numero 1"));
n2 = parseFloat(prompt("Introduce el numero 2"));
n3 = parseFloat(prompt("Introduce el numero 3"));

if(n1 < 10 && n2 < 10 && n3 < 10){
	menores = true;
}
else{
	menores = false;
}
alert(menores);