let side, perim, area;
side = parseInt(prompt("Introduzca el lado del rectángulo"));
perim = (4*side);
area = (side*side);
alert("El permietro es " + perim + " y el area " + area);
