let n1, n2, n3, n4;
n1 = parseInt(prompt("Introduzca el primer numero"));
n2 = parseInt(prompt("Introduzca el segundo numero"));
n3 = parseInt(prompt("Introduzca el tercer numero"));
n4 = parseInt(prompt("Introduzca el cuarto numero"));
add = (n1+n2);
mult = (n3*n4);
alert("La suma es " + add);
alert("La multiplicacion es " + mult);
