let n1, n2, n3, n4, avg;
n1 = parseFloat(prompt("Introduce el primer número"));
n2 = parseFloat(prompt("Introduce el segundo número"));
n3 = parseFloat(prompt("Introduce el tercer número"));
n4 = parseFloat(prompt("Introduce el cuarto número"));
avg = ((n1+n2+n3+n4)/4); 
alert("La media es " + avg);