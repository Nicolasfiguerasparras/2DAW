let price, qtty, total;
price = parseFloat(prompt("Introduce el precio del arculo"));
qtty = parseFloat(prompt("Introduce la cantidad de articulos"));
total = (qtty*price);
alert(total);

function myFuntion(bill){
	document.getElementById("bill1").innerHTML = price;
}

function myFunction2(bill2){
	document.getElementById("bill2").innerHTML = qtty;
}

function myFunction(bill3){
	document.getElementById("bill3").innerHTML = total;
}

